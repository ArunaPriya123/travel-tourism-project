from django.apps import AppConfig


class LoginmoduleConfig(AppConfig):
    name = 'loginmodule'
