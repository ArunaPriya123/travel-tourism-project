from django.apps import AppConfig


class BookticketappConfig(AppConfig):
    name = 'BookTicketApp'
