from django.apps import AppConfig


class PaymentappConfig(AppConfig):
    name = 'PaymentApp'
