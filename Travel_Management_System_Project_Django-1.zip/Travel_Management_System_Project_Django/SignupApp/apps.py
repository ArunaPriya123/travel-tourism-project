from django.apps import AppConfig


class SignupappConfig(AppConfig):
    name = 'SignupApp'
